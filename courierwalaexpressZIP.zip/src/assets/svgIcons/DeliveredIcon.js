import * as React from "react"
import Svg, { Path } from "react-native-svg"

function SvgComponent(props) {
  return (
    <Svg
      width={24}
      height={24}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Path
        d="M6 3c-.5 0-.9.2-1.2.6L3.5 5.2c-.3.4-.5.8-.5 1.3V19c0 1.1.9 2 2 2h8.3c-.2-.6-.3-1.3-.3-2 0-3.3 2.7-6 6-6 .7 0 1.4.1 2 .3V6.5c0-.5-.2-.9-.5-1.3l-1.4-1.7c-.2-.3-.6-.5-1.1-.5H6zm-.1 1h12l.9 1H5.1l.8-1zM6 15h6v3H6v-3zm15.3.8l-3.6 3.6-1.6-1.6L15 19l2.8 3 4.8-4.8-1.3-1.4z"
        fill="#4F4F4F"
      />
    </Svg>
  )
}

export default SvgComponent
