import { StyleSheet, Platform } from 'react-native'


const STYLE_1 = "Insured-Tag"
 
export default StyleSheet.create({
 
TEXTSTYLE_BLACK: {
color: "black"
},
 
TEXTSTYLE_WHITE: {
color: "white"
},
 
STYLE_1_A22: {
fontSize: 10,
fontFamily: STYLE_1
},
 
STYLE_1_A30: {
fontSize: 30,
fontFamily: STYLE_1
},
})
